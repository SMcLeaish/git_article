# Python Intro Companion Notebooks

1. Numeric variables
2. Logic
3. Looping
