# Beyond Numerics Companion notebooks

Instructions for are included within each notebook.

These notebooks are currently also stored in the lectures repository
